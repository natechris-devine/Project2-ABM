/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ABMBackend;

import java.util.ArrayList;
import java.util.*;

/**
 *
 * @author Nathaniel
 */
public class TrialAndError {

    private ArrayList<String[]> accountData = new ArrayList<String[]>();
    private ArrayList<PersonalClient> personalClientData = new ArrayList<PersonalClient>();
    private ArrayList<BusinessClient> businessClientData = new ArrayList<BusinessClient>();
    private ArrayList<ABMCard> cardList = new ArrayList<ABMCard>();


    private void initialize() {
        //  Business clients first    TRN,     Last Name, First Name, Address,           Parish,    Phone #1, Phone #2  , accType, AccBalace
        accountData.add(new String[]{"011111111", "ATL Ltd.","ATL Ltd.","33 Cherry Lane","Kingston","7705067","8765567","investment","45000","savings","586000"});
        accountData.add(new String[]{"023456789", "Sangsters","Sangsters","6 Mimosa Close","Kingston","3368736","8599403","chequing","1500000"});
        accountData.add(new String[]{"029564873","Burger King","Burger King","15 Cypress Ave.","Kingston","4430098","7382920","savings","1009","chequing","843000"});
        accountData.add(new String[]{"050375967","KFC Ltd.","KFC Ltd.","28 Igsora Close","Kingston","4443322","3345678","chequing","347890"});
        accountData.add(new String[]{"058086900","John's","John's","11 Magnolia Ave.","Kingston","5677877","8493321","investment","999998"});
        //                            TRN,     Last Name, First Name, Address,    Parish,    Phone #, Card #, Card pin, accType, AccBalace
        accountData.add(new String[]{"111111111", "James","Mark","33 Cherry Lane","Kingston","7705067","00000000","1234","savings","500000","direct banking","90000"});
        accountData.add(new String[]{"123456789", "Dobbs","Martha","6 Mimosa Close","Kingston","3368736","11111111","1234","direct banking", "100000"});
        accountData.add(new String[]{"109564873","Dunkley","Mary","15 Cypress Ave.","Kingston","4430098","22222222","1234","savings", "2500000","chequing","750000"});
        accountData.add(new String[]{"150375967","Morgan","Jesse","28 Igsora Close","Kingston","4443322","33333333","1234","investment","3000000"});
        accountData.add(new String[]{"158086900","Hewwit","John","11 Magnolia Ave.","Kingston","5677877","44444444","1234","chequing","350000"});

    }

    private void createObjects() {
        String[] ai;
        for (int i=0;i<accountData.size();i++ ) {
            ai = accountData.get(i);
            if (ai[0].startsWith("1")) {
                PersonalClient pc = new PersonalClient(ai[0],ai[1],ai[2],ai[3],ai[4],ai[5],ai[6],ai[7]);
                //pc.addAccount(ai[8],Double.parseDouble(ai[9]));
                try{
                    for(int j = 8; j<ai.length;j+=2){
                        pc.addAccount(ai[j],Double.parseDouble(ai[j+1]));
                    }
                }catch(Exception e){}
                cardList.add(pc.getCard());
                personalClientData.add(pc);
            } else {
                BusinessClient bc = new BusinessClient(ai[0],ai[1],ai[2],ai[3],ai[4],ai[5],ai[6]);
                //bc.addAccount(ai[7],Double.parseDouble(ai[8]));
                try{
                    for(int m = 7; m <ai.length;m+=2){
                        bc.addAccount(ai[m],Double.parseDouble(ai[m+1]));
                    }
                }catch(Exception e){}
                businessClientData.add(bc);
            }
        }
        //Assigning signatories
        assignSignatories(0);
        assignSignatories(1);
        assignSignatories(2);
        assignSignatories(3);
        assignSignatories(2,3);
        assignSignatories(4);

    }

    private void assignSignatories(int pCIndex, int bCIndex){
        personalClientData.get(pCIndex).addBusiness(businessClientData.get(bCIndex));
        businessClientData.get(bCIndex).addSignatory(personalClientData.get(pCIndex));
    }

    private void assignSignatories(int index){
        assignSignatories(index, index);
    }

    public void printData(){
        for(PersonalClient p: personalClientData)
            System.out.println(p + "\n");

        for(BusinessClient b: businessClientData)
            System.out.println(b + "\n");

        for(ABMCard c: cardList)
            System.out.println(c + "\n");
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TrialAndError tae = new TrialAndError();
        TransactionLogger t = new TransactionLogger();

        //Adding data to file
        tae.initialize();
        tae.createObjects();
        tae.printData();
        t.recordTransaction("Mark Clarke", "Deposit", "100", "65300");
        t.recordTransaction("William Ford", "Withdraw", "500", "78000");

        FileManager.saveData(tae.cardList, tae.personalClientData, tae.businessClientData,t.getLog());



        //Opening data from file

        FileManager fm = new FileManager();
        t.setLog(fm.getTransactionLog());
        tae.cardList = fm.getABMCards();
        tae.personalClientData = fm.getPersonalClients();
        tae.businessClientData = fm.getBusinessClients();
        System.out.println(t.toString());
        tae.printData();

        if (tae.personalClientData.get(0).getCard() == tae.cardList.get(0))
            System.out.println("Eureka! It's the same memory address!");
        else
            System.out.println("Sometimes you win, sometimes you gotta go again");

        System.out.println(tae.personalClientData.get(0).getBusinesses().get(0));
        System.out.println(tae.businessClientData.get(0));
        if(tae.businessClientData.get(0).getTRN().equals(tae.personalClientData.get(0).getBusinesses().get(0).getTRN()))
//        if(tae.businessClientData.get(0).equals(tae.personalClientData.get(0).getBusinesses().get(0)))
            System.out.println("Good to go!");
        else
            System.out.println("HMMMmmm...");
    }

}
