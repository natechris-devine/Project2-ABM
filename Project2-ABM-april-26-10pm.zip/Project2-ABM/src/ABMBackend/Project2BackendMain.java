package ABMBackend;
import java.util.*;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Nathaniel
 */
public class Project2BackendMain {

    private ArrayList<String[]> accountData = new ArrayList<String[]>();
    private ArrayList<PersonalClient> personalClientData = new ArrayList<PersonalClient>();
    private ArrayList<BusinessClient> businessClientData = new ArrayList<BusinessClient>();
    private ArrayList<ABMCard> cardList = new ArrayList<ABMCard>();

    private void initialize() {
        //  Business clients first    TRN,     Last Name, First Name, Address,    Parish,    Phone #, Card #, Card pin
        accountData.add(new String[]{"011111111", "ATL Ltd.","ATL Ltd.","33 Cherry Lane","Kingston","7705067","8765567"});
        accountData.add(new String[]{"023456789", "Sangsters","Sangsters","6 Mimosa Close","Kingston","3368736","8599403"});
        accountData.add(new String[]{"029564873","Burger King","Burger King","15 Cypress Ave.","Kingston","4430098","7382920"});
        accountData.add(new String[]{"050375967","KFC Ltd.","KFC Ltd.","28 Igsora Close","Kingston","4443322","3345678"});
        accountData.add(new String[]{"058086900","John's","John's","11 Magnolia Ave.","Kingston","5677877","8493321"});
        //                            TRN,     Last Name, First Name, Address,    Parish,    Phone #, Card #, Card pin
        accountData.add(new String[]{"111111111", "James","Mark","33 Cherry Lane","Kingston","7705067","00000000","1234"});
        accountData.add(new String[]{"123456789", "Dobbs","Martha","6 Mimosa Close","Kingston","3368736","11111111","1234"});
        accountData.add(new String[]{"109564873","Dunkley","Mary","15 Cypress Ave.","Kingston","4430098","22222222","1234"});
        accountData.add(new String[]{"150375967","Morgan","Jesse","28 Igsora Close","Kingston","4443322","33333333","1234"});
        accountData.add(new String[]{"158086900","Hewwit","John","11 Magnolia Ave.","Kingston","5677877","44444444","1234"});

    }

    private void createObjects() {
        String[] ai;
        for (int i=0;i<accountData.size();i++ ) {
            ai = accountData.get(i);
            if (ai[0].startsWith("1")) {
                PersonalClient pc = new PersonalClient(ai[0],ai[1],ai[2],ai[3],ai[4],ai[5],ai[6],ai[7]);
                cardList.add(pc.getCard());
                personalClientData.add(pc);
            } else {
                BusinessClient bc = new BusinessClient(ai[0],ai[1],ai[2],ai[3],ai[4],ai[5],ai[6]);
                businessClientData.add(bc);
            }
        }
    }

    public BusinessClient trnToBusiness(String trn) {
        for (BusinessClient client: businessClientData ) {
            if (trn.equals(client.getTRN()))
                return client;
        }
        return null;
    }

    public Project2BackendMain() {
        initialize();
        createObjects();
    }


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Project2BackendMain tst = new Project2BackendMain();

    }


}
