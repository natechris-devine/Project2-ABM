package ABMBackend;

import java.io.Serializable;

public enum AccountType implements Serializable{
    savings ("Savings Account", 0.05),
    directbanking ("Direct Banking", 0.0),
    investment ("Investment Account", 0.15),
    chequing ("Chequing Account",0.0);

    private final String longname;
    private final double irate;
//    private final double dep_charge;
//    private final double with_charge;

    AccountType(String name, double rate){
        this.longname = name;
        this.irate = rate;
//        this.dep_charge = dchr;
//        this.with_charge = wchr;
    }

    public String longName(){
        return this.longname;
    }

    public double interestRate(){
        return this.irate;
    }

//    public double depositFee(){
//        return this.dep_charge;
//    }
//
//    public double withdrawFee(){
//        return this.with_charge;
//    }
}
